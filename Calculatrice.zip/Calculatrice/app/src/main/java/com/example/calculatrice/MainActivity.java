package com.example.calculatrice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView ecran ;
    TextView ecran2 ;
    String operation1 ;
    String operation2 ;
    String nb1 ;
    String nb2 ;
     Double nb11 ;
      Double nb22 ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ecran = findViewById(R.id.ecran);
        ecran.setText("");
        ecran2 = findViewById(R.id.ecran2);
        ecran2.setText("");
        nb1 = null;
        nb2 =null;
        operation1 = null;
        operation2= null;
    }

    public void affichier(View view) {
        Button btn = (Button) view;
        String chf =btn.getText().toString();
        ecran.setText(ecran.getText() +chf);
        ecran2.setText(ecran2.getText() +chf);
    }

    public void ope(View view) {
        Button btn = (Button) view;
        nb1= ecran.getText().toString();
        nb11 = Double.parseDouble(nb1);
         operation1 =btn.getText().toString();
         ecran2.setText(nb1 + " " + operation1 );
        ecran.setText("");
    }
    public void cee(View view){
        nb1= ecran.getText().toString();
        int a = (int) (Double.parseDouble(nb1)/10);

        ecran.setText(Integer.toString(a));
        ecran2.setText(Integer.toString(a));

    }
    public void cos(View view) {



        operation2 ="cos";
        if(operation1!=null)
        ecran2.setText(nb1 + operation1 + operation2 );
        else
            ecran2.setText( operation2 );
        ecran.setText("");
    }
    public void sin(View view) {



        operation2 ="sin";
        if(operation1!=null)
            ecran2.setText(nb1 + operation1 + operation2 );
        else
            ecran2.setText( operation2 );
        ecran.setText("");
    }
    public void tan(View view) {



        operation2 ="tan";
        if(operation1!=null)
            ecran2.setText(nb1 + operation1 + operation2 );
        else
            ecran2.setText( operation2 );
        ecran.setText("");
    }

    public void inverse(View view) {

        nb1= ecran.getText().toString();
        nb11 = Double.parseDouble(nb1);

        operation1 ="1/x";

            ecran2.setText("1/"+ nb1);

    }
    public void egal(View view) {
        Button btn = (Button) view;
        nb2= ecran.getText().toString();
         nb22 = Double.parseDouble(nb2);
          Double rel = resultat(operation1,operation2,nb22,nb11) ;

        ecran2.setText(ecran2.getText().toString() + " = "+ Double.toString(rel));
        ecran.setText( Double.toString(rel));
        operation1=null;
        operation2=null;
    }
    public Double resultat(String op1,String op2,Double nbr22,Double nbr11){
        Double res =0.0;
        String div0="Math erreur";
        if(operation2!=null){
            switch(operation2){

                case "cos":  nb22= Math.cos(nb22);res=nb22 ;break;
                case  "tan": nb22 = Math.tan(nb22);res=nb22 ;break;

                case  "sin": nb22 = Math.sin(nb22);res=nb22 ;break;


                default: res = 0.0;break;
            }
        }

        if(operation1!=null){
            switch(operation1){
                case "+" : res = nb11 + nb22 ;break;
                case "-": res = nb11 - nb22 ;break;
                case "X" : res = nb11 * nb22 ;break;
                case "/" : res = nb11 / nb22 ;break;
                case  "1/x": if(nb11!=0.0){nb11 = 1/nb11;res=nb11;}else{ecran2.setText(div0);ecran.setText("");} break;
                default: res = 0.0;break;
            }
        }
        return res ;
    }
}